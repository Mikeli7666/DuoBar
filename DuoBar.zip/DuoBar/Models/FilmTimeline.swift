#if DEBUG
import Foundation

/// Hands-free driver for promo capture.
///
/// When `~/duobar-film/timeline.json` exists at launch, the player waits
/// `startDelay` seconds and then steps the app's DEBUG status overrides
/// through the scripted beats, so the real UI can be screen-recorded without
/// anyone touching the Debug Simulator menus. Every step is mirrored to
/// `~/duobar-film/progress.log`. Delete or rename the JSON to run the app
/// normally; Release builds never compile this file's contents.
@MainActor
final class FilmTimelinePlayer {
    static let shared = FilmTimelinePlayer()

    private static var directory: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("duobar-film", isDirectory: true)
    }

    /// True while a film timeline is present; the popover hides its Debug
    /// Simulator row in that case so captures show the production UI.
    static var captureConfigured: Bool {
        FileManager.default.fileExists(
            atPath: directory.appendingPathComponent("timeline.json").path
        )
    }

    /// The stage backdrop lives in a single wallpaper.jpg the stage reads
    /// once per launch. A timeline may carry its backdrop inline (base64)
    /// or point at an image URL to fetch before the stage opens, so a scene
    /// can be pushed as one small text file; with neither key, any stale
    /// wallpaper is removed and the stage uses its gradient.
    private static func syncWallpaper(_ base64: String?) {
        syncWallpaper(data: base64.flatMap { Data(base64Encoded: $0) })
    }

    private static func syncWallpaper(data: Data?) {
        let url = directory.appendingPathComponent("wallpaper.jpg")
        if let data, !data.isEmpty {
            try? data.write(to: url, options: .atomic)
        } else {
            try? FileManager.default.removeItem(at: url)
        }
    }

    private var runTask: Task<Void, Never>?
    private var speedTask: Task<Void, Never>?
    private weak var store: SystemStatusStore?
    private weak var menuBarController: MenuBarController?
    private var stageMode = false

    /// Mirrors of the state most recently applied. Each step starts from these
    /// so partial updates compose instead of resetting the whole scene.
    private var battery = BatteryStatus(
        percentage: 100, isCharging: false, isPluggedIn: false,
        isFullyCharged: false, isAvailable: true
    )
    private var network = NetworkStatus(
        isAvailable: true, isConnected: true, transport: .wifi,
        interfaceName: "en0", isWiFiPoweredOn: true, ssid: "Mike's home", rssi: -42
    )
    private var audio = DebugAudioDeviceState.builtIn.status
    private var savedMenuBarPercentage: Bool?

    // MARK: - Script schema

    private struct Config: Decodable {
        var startDelay: Double?
        var loop: Bool?
        var restoreAtEnd: Bool?
        var stage: Bool?
        var wallpaperBase64: String?
        var wallpaperURL: String?
        var steps: [Step]
    }

    private struct Step: Decodable {
        var duration: Double
        var note: String?
        var battery: BatteryPatch?
        var network: NetworkPatch?
        var volume: Double?
        var audioDevice: String?
        var audioInput: String?
        var airPodsEvent: Bool?
        var speed: SpeedPatch?
        var speedOff: Bool?
        var popover: Bool?
        var menuBarPercentage: Bool?
        var adaptive: String?
    }

    private struct BatteryPatch: Decodable {
        var percentage: Int?
        var charging: Bool?
        var pluggedIn: Bool?
        var fullyCharged: Bool?
        var lowPowerMode: Bool?
    }

    private struct NetworkPatch: Decodable {
        var mode: String?
        var ssid: String?
        var rssi: Int?
    }

    private struct SpeedPatch: Decodable {
        var down: Double
        var up: Double
        var jitter: Bool?
    }

    // MARK: - Entry point

    func startIfConfigured(store: SystemStatusStore, menuBarController: MenuBarController) {
        guard runTask == nil else { return }
        let url = Self.directory.appendingPathComponent("timeline.json")
        guard let data = try? Data(contentsOf: url) else { return }
        let config: Config
        do {
            config = try JSONDecoder().decode(Config.self, from: data)
        } catch {
            NSLog("[DuoBar Film] timeline.json failed to decode: %@", "\(error)")
            return
        }
        self.store = store
        self.menuBarController = menuBarController
        if let urlString = config.wallpaperURL, let url = URL(string: urlString) {
            // Fetch the backdrop before the stage opens so it never shows
            // the wrong scene; a failed fetch falls back to the gradient.
            runTask = Task { @MainActor in
                var request = URLRequest(url: url)
                request.timeoutInterval = 10
                let data = try? await URLSession.shared.data(for: request).0
                Self.syncWallpaper(data: data)
                log("loaded \(config.steps.count) steps, wallpaper \(data == nil ? "fetch failed" : "ok")")
                self.openStageIfNeeded(config)
                await self.run(config)
            }
        } else {
            Self.syncWallpaper(config.wallpaperBase64)
            log("loaded \(config.steps.count) steps")
            openStageIfNeeded(config)
            runTask = Task { @MainActor in
                await self.run(config)
            }
        }
    }

    private func openStageIfNeeded(_ config: Config) {
        guard let store else { return }
        stageMode = config.stage == true
        if stageMode {
            FilmStageController.shared.open(store: store)
        }
    }

    // MARK: - Playback

    private func run(_ config: Config) async {
        if let delay = config.startDelay, delay > 0 {
            try? await Task.sleep(for: .seconds(delay))
        }
        guard let store else { return }
        // The DEBUG default full-charge delay is one minute (hardware QA);
        // for filming, the battery -> adaptive switch must happen on cue.
        store.laptopRingModeController.setFullChargeDelay(.immediately)
        savedMenuBarPercentage = UserDefaults.standard
            .object(forKey: PreferenceKeys.showBatteryPercentageInMenuBar) as? Bool
        UserDefaults.standard.set(true, forKey: PreferenceKeys.showBatteryPercentageInMenuBar)
        log("playback started")
        repeat {
            for (index, step) in config.steps.enumerated() {
                if Task.isCancelled { break }
                log("step \(index + 1)/\(config.steps.count): \(step.note ?? "")")
                await apply(step)
                try? await Task.sleep(for: .seconds(step.duration))
                stopSpeedJitter()
            }
        } while config.loop == true && !Task.isCancelled
        if config.restoreAtEnd == true {
            restore()
        }
        log("playback finished")
    }

    private func restore() {
        guard let store else { return }
        stopSpeedJitter()
        store.applyDebugNetworkSpeed(nil)
        AdaptiveRingMonitor.shared.clearDebugSyntheticInput()
        if stageMode {
            PopoverPresentationState.shared.hide()
        } else {
            menuBarController?.setPopoverVisibleForMarketingCapture(false)
        }
        store.restoreLiveStatus()
        if let savedMenuBarPercentage {
            UserDefaults.standard.set(savedMenuBarPercentage, forKey: PreferenceKeys.showBatteryPercentageInMenuBar)
        } else {
            UserDefaults.standard.removeObject(forKey: PreferenceKeys.showBatteryPercentageInMenuBar)
        }
    }

    // MARK: - Step application

    private func apply(_ step: Step) async {
        guard let store else { return }

        if let patch = step.battery {
            if let value = patch.percentage { battery.percentage = value }
            if let value = patch.charging { battery.isCharging = value }
            if let value = patch.pluggedIn { battery.isPluggedIn = value }
            if let value = patch.fullyCharged { battery.isFullyCharged = value }
            if let value = patch.lowPowerMode { battery.isLowPowerModeEnabled = value }
            battery.isAvailable = true
            store.applyDebugBatteryStatus(battery)
        }

        if let patch = step.network {
            switch patch.mode ?? "wifi" {
            case "disconnected":
                network.isConnected = false
                network.ssid = nil
                network.rssi = nil
            case "wifiOff":
                network.isWiFiPoweredOn = false
                network.isConnected = false
                network.ssid = nil
                network.rssi = nil
            case "ethernet":
                network.transport = .ethernet
                network.interfaceName = "en1"
                network.isConnected = true
                network.ssid = nil
                network.rssi = nil
            default:
                network.transport = .wifi
                network.interfaceName = "en0"
                network.isWiFiPoweredOn = true
                network.isConnected = true
                if let ssid = patch.ssid { network.ssid = ssid }
                if let rssi = patch.rssi { network.rssi = rssi }
                if network.ssid == nil { network.ssid = "Wi-Fi Network" }
                if network.rssi == nil { network.rssi = -50 }
            }
            network.isAvailable = true
            store.applyDebugNetworkStatus(network)
        }

        if let device = step.audioDevice {
            let preset: DebugAudioDeviceState?
            switch device {
            case "airPods": preset = .airPods
            case "headphones": preset = .headphones
            case "builtIn": preset = .builtIn
            default: preset = nil
            }
            if let preset {
                let volume = audio.volume
                let input = audio.defaultInput
                let inputs = audio.availableInputs
                audio = preset.status
                audio.volume = volume
                audio.defaultInput = input
                audio.availableInputs = inputs
                store.applyDebugAudioStatus(audio)
            }
        }

        if let volume = step.volume {
            audio.volume = OutputVolumeStatus(
                level: volume, isMuted: volume <= 0, isSettable: true, isMuteSettable: true
            )
            store.applyDebugAudioStatus(audio)
        }

        if let input = step.audioInput {
            let builtInMic = AudioDeviceStatus(
                uid: "film-builtin-mic", name: "MacBook Pro Microphone",
                transport: .builtIn, isAlive: true
            )
            let externalMic = AudioDeviceStatus(
                uid: "film-external-mic", name: "External Microphone",
                transport: .usb, isAlive: true
            )
            audio.availableInputs = [builtInMic, externalMic]
            audio.defaultInput = input == "externalMic" ? externalMic : builtInMic
            store.applyDebugAudioStatus(audio)
        }

        if step.airPodsEvent == true,
           let device = audio.connectedBluetoothOutputs.first(where: { $0.transport.isBluetooth }) {
            store.priorityController.present(
                StatusEvent(kind: .audioDeviceConnected(device), priority: .informational, duration: step.duration + 2)
            )
        }

        if step.speedOff == true {
            stopSpeedJitter()
            store.applyDebugNetworkSpeed(nil)
        } else if let speed = step.speed {
            stopSpeedJitter()
            let base = NetworkSpeed(downloadBytesPerSecond: speed.down, uploadBytesPerSecond: speed.up)
            store.applyDebugNetworkSpeed(base)
            if speed.jitter == true {
                speedTask = Task { @MainActor in
                    while !Task.isCancelled {
                        try? await Task.sleep(for: .seconds(1.1))
                        if Task.isCancelled { break }
                        let jittered = NetworkSpeed(
                            downloadBytesPerSecond: base.downloadBytesPerSecond * Double.random(in: 0.72...1.3),
                            uploadBytesPerSecond: base.uploadBytesPerSecond * Double.random(in: 0.72...1.3)
                        )
                        self.store?.applyDebugNetworkSpeed(jittered)
                    }
                }
            }
        }

        if let adaptive = step.adaptive {
            await applyAdaptive(adaptive)
        }

        if let popover = step.popover {
            if stageMode {
                // Drive the stage popover's presentation directly; the real
                // menu-bar panel stays closed during stage captures.
                if popover {
                    PopoverPresentationState.shared.prepareToShow()
                    PopoverPresentationState.shared.show()
                } else {
                    PopoverPresentationState.shared.hide()
                }
            } else {
                menuBarController?.setPopoverVisibleForMarketingCapture(popover)
            }
        }

        if let menuBarPercentage = step.menuBarPercentage {
            UserDefaults.standard.set(menuBarPercentage, forKey: PreferenceKeys.showBatteryPercentageInMenuBar)
        }
    }

    // MARK: - Adaptive ring (mirrors the Debug Simulator's own sequencing)

    private func applyAdaptive(_ name: String) async {
        guard let store else { return }
        if name == "off" {
            AdaptiveRingMonitor.shared.clearDebugSyntheticInput()
            store.applyDebugAdaptiveBatteryBaseline()
            battery.isCharging = false
            battery.isPluggedIn = false
            battery.isFullyCharged = false
            return
        }
        let scenario: AdaptiveRingSyntheticScenario?
        switch name {
        case "neutral": scenario = .neutral
        case "cpuHigh": scenario = .cpuHigh
        case "memoryPressure": scenario = .memoryPressure
        case "memoryCritical": scenario = .memoryCritical
        case "thermalCritical": scenario = .thermalCritical
        default: scenario = nil
        }
        guard let scenario else { return }

        if store.laptopRingModeState.mode == .adaptive {
            useScenario(scenario)
            return
        }
        if store.laptopRingModeState.targetPercentage != DebugBatteryLevel.eighty.rawValue
            || !store.status.battery.isCharging {
            store.applyDebugAdaptiveChargingBaseline()
            battery.isCharging = true
            battery.isPluggedIn = true
            battery.isFullyCharged = false
            try? await Task.sleep(for: .seconds(BatteryChargingAnimationProfile.entranceDuration))
        }
        useScenario(scenario)
        await Task.yield()
        store.reachDebugAdaptiveTarget()
    }

    private func useScenario(_ scenario: AdaptiveRingSyntheticScenario) {
        AdaptiveRingMonitor.shared.useDebugSyntheticInput(
            scenario.input,
            label: scenario.rawValue,
            preference: scenario == .memoryPressure ? .memory : .automatic
        )
    }

    // MARK: - Helpers

    private func stopSpeedJitter() {
        speedTask?.cancel()
        speedTask = nil
    }

    private func log(_ message: String) {
        NSLog("[DuoBar Film] %@", message)
        let line = "\(Date()) \(message)\n"
        let url = Self.directory.appendingPathComponent("progress.log")
        if let handle = try? FileHandle(forWritingTo: url) {
            defer { try? handle.close() }
            _ = try? handle.seekToEnd()
            try? handle.write(contentsOf: Data(line.utf8))
        } else {
            try? FileManager.default.createDirectory(at: Self.directory, withIntermediateDirectories: true)
            try? line.write(to: url, atomically: true, encoding: .utf8)
        }
    }
}
#endif
