import SwiftUI

struct VolumeStatusRow: View {
    let volume: OutputVolumeStatus
    let hasOutputDevice: Bool
    let playbackDeviceIdentifier: String?
    let onSetVolume: (Double) -> Bool
    let onSetMuted: (Bool) -> Bool

    @State private var feedbackInteraction = VolumeFeedbackInteraction()

    var body: some View {
        HStack(spacing: 11) {
            muteControl
                .frame(width: 28, height: 28)
                .background(.primary.opacity(0.10), in: Circle())

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(localized("Volume"))
                        .font(.system(size: 12.5, weight: .semibold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.82)
                    Spacer()
                    Text(stateText)
                        .font(.system(size: 10.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.secondary)
                        .monospacedDigit()
                        .lineLimit(1)
                        .minimumScaleFactor(0.72)
                }

                if volume.isSettable, let level = volume.level {
                    CapsuleVolumeSlider(
                        level: level,
                        isMuted: volume.isMuted,
                        onChange: handleUserVolumeChange,
                        onEditingChanged: handleSliderEditingChanged
                    )
                    .accessibilityLabel(localized("Output volume"))
                    .accessibilityValue(stateText)
                } else {
                    Text(hasOutputDevice ? localized("Controlled by device") : localized("Volume unavailable"))
                        .font(.system(size: 10.5))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.72)
                }
            }
        }
        .padding(.horizontal, 10)
        .frame(height: 70)
        .popoverCardBackground(cornerRadius: 11, fillOpacity: 0.045)
    }

    @ViewBuilder
    private var muteControl: some View {
        if volume.isMuteSettable {
            Button {
                handleUserMuteChange()
            } label: {
                Image(systemName: volumeSymbol)
                    .font(.system(size: 13, weight: .semibold))
                    .frame(width: 28, height: 28)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .help(volume.isMuted ? localized("Unmute") : localized("Mute"))
            .accessibilityLabel(volume.isMuted ? localized("Unmute output") : localized("Mute output"))
        } else {
            Image(systemName: volumeSymbol)
                .font(.system(size: 13, weight: .semibold))
        }
    }

    private var volumeSymbol: String {
        guard let percentage = volume.percentage else { return "speaker" }
        if volume.isMuted || percentage == 0 { return "speaker.slash.fill" }
        switch percentage {
        case 1...33: return "speaker.wave.1"
        case 34...66: return "speaker.wave.2"
        default: return "speaker.wave.3"
        }
    }

    private var stateText: String {
        if volume.isMuted { return localized("Muted") }
        return volume.percentage.map { localized("%d%%", $0) } ?? "—"
    }

    private func handleUserVolumeChange(_ level: Double) {
        beginSliderInteractionIfNeeded()
        var interaction = feedbackInteraction
        guard feedbackInteraction.allowsVolumeUpdates else {
            interaction.recordVolumeUpdate(
                previousStatus: volume,
                requestedLevel: level,
                writeSucceeded: false
            )
            $feedbackInteraction.wrappedValue = interaction
            return
        }

        let writeSucceeded = onSetVolume(level)
        interaction.recordVolumeUpdate(
            previousStatus: volume,
            requestedLevel: level,
            writeSucceeded: writeSucceeded
        )
        $feedbackInteraction.wrappedValue = interaction
    }

    private func handleSliderEditingChanged(_ isEditing: Bool) {
        if isEditing {
            beginSliderInteractionIfNeeded()
            return
        }
        var interaction = feedbackInteraction
        guard interaction.endEditing() else {
            $feedbackInteraction.wrappedValue = interaction
            return
        }
        $feedbackInteraction.wrappedValue = interaction
        VolumeFeedbackSound.play(on: playbackDeviceIdentifier)
    }

    private func beginSliderInteractionIfNeeded() {
        var interaction = feedbackInteraction
        interaction.beginEditing(previousStatus: volume) {
            onSetMuted(false)
        }
        $feedbackInteraction.wrappedValue = interaction
    }

    private func handleUserMuteChange() {
        let writeSucceeded = onSetMuted(!volume.isMuted)
        var interaction = feedbackInteraction
        guard interaction.shouldPlayForUnmute(
            previousStatus: volume,
            writeSucceeded: writeSucceeded
        ) else {
            $feedbackInteraction.wrappedValue = interaction
            return
        }
        $feedbackInteraction.wrappedValue = interaction

        VolumeFeedbackSound.play(on: playbackDeviceIdentifier)
    }
}

/// Thick capsule slider in the style of Control Center's Display / Sound
/// rows: grey glass track, white fill, a white knob riding the fill's end,
/// and speaker glyphs at both ends inside the track.
private struct CapsuleVolumeSlider: View {
    let level: Double
    let isMuted: Bool
    let onChange: (Double) -> Void
    let onEditingChanged: (Bool) -> Void

    @State private var isDragging = false

    private let trackHeight: CGFloat = 26
    private let knobDiameter: CGFloat = 24

    var body: some View {
        GeometryReader { proxy in
            let width = proxy.size.width
            let clamped = min(max(level, 0), 1)
            let fillWidth = max(trackHeight, CGFloat(clamped) * width)
            ZStack(alignment: .leading) {
                Capsule(style: .continuous)
                    .fill(.primary.opacity(0.12))
                Capsule(style: .continuous)
                    .fill(.white.opacity(isMuted ? 0.35 : 0.92))
                    .frame(width: fillWidth)
                HStack {
                    Image(systemName: "speaker.fill")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(.black.opacity(0.45))
                        .padding(.leading, 8)
                    Spacer()
                    Image(systemName: "speaker.wave.3.fill")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(.primary.opacity(0.45))
                        .padding(.trailing, 8)
                }
                Circle()
                    .fill(.white)
                    .frame(width: knobDiameter, height: knobDiameter)
                    .shadow(color: .black.opacity(0.25), radius: 2, y: 1)
                    .offset(x: fillWidth - knobDiameter - 1)
            }
            .contentShape(Capsule(style: .continuous))
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        if !isDragging {
                            isDragging = true
                            onEditingChanged(true)
                        }
                        onChange(Double(min(max(value.location.x / width, 0), 1)))
                    }
                    .onEnded { _ in
                        isDragging = false
                        onEditingChanged(false)
                    }
            )
        }
        .frame(height: trackHeight)
        .accessibilityElement(children: .ignore)
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: onChange(min(level + 0.1, 1))
            case .decrement: onChange(max(level - 0.1, 0))
            @unknown default: break
            }
        }
    }
}
