import AppKit
import SwiftUI

struct StatusPopoverView: View {
    @ObservedObject private var statusStore: SystemStatusStore
    @AppStorage(PreferenceKeys.showBatteryPercentage) private var showBatteryPercentage = true
    @AppStorage(PreferenceKeys.batteryColorCoding) private var batteryColorCoding = false
    private let onClose: () -> Void

    init(statusStore: SystemStatusStore, onClose: @escaping () -> Void) {
        self.statusStore = statusStore
        self.onClose = onClose
    }

    var body: some View {
        PopoverGlassContainer {
            panelContent
        }
    }

    private var panelContent: some View {
        VStack(spacing: 8) {
            StatusRow(
                symbol: networkSymbol,
                title: localized("Network"),
                detail: networkDetail,
                speedText: networkSpeedText,
                stateText: networkState,
                tint: .primary,
                accessory: .disclosure,
                trailing: wifiPowerToggle,
                onActivate: openNetworkSettings,
                activationHint: networkSettingsHint
            )

            NearbyWiFiButton(
                statusStore: statusStore,
                onOpenSettings: openWiFiSettings
            )

            VolumeStatusRow(
                volume: statusStore.status.audio.volume,
                hasOutputDevice: statusStore.status.audio.defaultOutput != nil,
                playbackDeviceIdentifier: statusStore.status.audio.defaultOutput?.uid,
                onSetVolume: statusStore.setVolume,
                onSetMuted: statusStore.setMuted
            )

            Button(action: openBatterySettings) {
                BatteryStatusRow(
                    battery: statusStore.status.battery,
                    showPercentage: showBatteryPercentage,
                    showsDisclosure: true,
                    timeEstimate: statusStore.batteryTimeEstimate
                )
            }
            .buttonStyle(.plain)
            .frame(maxWidth: .infinity)
            .accessibilityHint(localized("Open Battery Settings"))

            AudioOutputRow(
                symbol: audioOutputSymbol,
                title: localized("Audio Output"),
                detail: audioOutputDetail,
                stateText: audioOutputState,
                outputs: statusStore.status.audio.selectableOutputs,
                selectedUID: statusStore.status.audio.defaultOutput?.uid,
                onSelect: { statusStore.setDefaultOutput(uid: $0) },
                onOpenSoundSettings: openSoundSettings,
                onOpenBluetoothSettings: { SystemSettingsOpener.open(.bluetooth) }
            )

            AudioOutputRow(
                symbol: audioInputSymbol,
                title: localized("Audio Input"),
                detail: audioInputDetail,
                stateText: audioInputState,
                outputs: statusStore.status.audio.selectableInputs,
                selectedUID: statusStore.status.audio.defaultInput?.uid,
                onSelect: { statusStore.setDefaultInput(uid: $0) },
                onOpenSoundSettings: openSoundSettings,
                onOpenBluetoothSettings: {},
                emptyText: localized("No input devices"),
                failureText: localized("Unable to Switch Input"),
                hint: localized("Select audio input"),
                showsBluetoothSettings: false
            )

            #if DEBUG
            if !FilmTimelinePlayer.captureConfigured {
                DebugStatusSimulatorView(statusStore: statusStore)
            }
            #endif

            // Development diagnostics belong in the dedicated DEBUG diagnostics
            // surface, never in the production status-card hierarchy.
            HStack(spacing: 6) {
                settingsAction

                Spacer()

                Button(localized("Quit DuoBar")) {
                    NSApp.terminate(nil)
                }
                .buttonStyle(.plain)
                .foregroundStyle(.secondary)
            }
            .font(.system(size: 11.5, weight: .medium))
            .padding(.horizontal, 10)
            .frame(height: 34)
            .popoverCardBackground(cornerRadius: 17, fillOpacity: 0.045)
        }
        .padding(12)
        .frame(width: 304)
        .onAppear {
            NSApp.activate(ignoringOtherApps: true)
        }
    }

    private var settingsAction: some View {
        // Deliberately not SettingsLink: the Settings scene's window
        // cannot stay resizable (the scene strips the flag), so settings
        // open in the app's own window via SettingsPresenter.
        Button(action: openSettings) {
            settingsLabel
        }
        .buttonStyle(.plain)
    }

    private var settingsLabel: some View {
        Label(localized("Settings"), systemImage: "gearshape")
    }

    private func openSettings() {
        SettingsPresenter.show()
        onClose()
    }

    private var networkSettingsHint: String {
        SystemSettingsOpener.pane(for: statusStore.status.network) == .network
            ? localized("Open Network Settings")
            : localized("Open Wi-Fi Settings")
    }

    private func openNetworkSettings() {
        // Mirrors Apple's own Wi-Fi icon (#17): holding Option while
        // activating the row opens the general Network settings instead of
        // the transport-specific pane.
        if NSEvent.modifierFlags.contains(.option) {
            _ = SystemSettingsOpener.open(.network)
        } else {
            _ = SystemSettingsOpener.open(SystemSettingsOpener.pane(for: statusStore.status.network))
        }
        onClose()
    }

    private func openWiFiSettings() {
        _ = SystemSettingsOpener.open(.wifi)
        onClose()
    }

    private func openBatterySettings() {
        _ = SystemSettingsOpener.open(.battery)
        onClose()
    }

    private func openSoundSettings() {
        _ = SystemSettingsOpener.open(.sound)
        onClose()
    }

    private var networkSymbol: String {
        let network = statusStore.status.network
        guard network.isConnected else { return "network.slash" }
        switch network.transport {
        case .wifi: return "wifi"
        case .ethernet: return "cable.connector.horizontal"
        case .other: return "ellipsis.circle"
        case .none: return "network.slash"
        }
    }

    private var networkDetail: String {
        let network = statusStore.status.network
        if statusStore.wifiPowerControlError != nil {
            return localized("Unable to change Wi-Fi power")
        }
        guard network.isAvailable else { return localized("No network interface") }
        guard network.isConnected else {
            return network.isWiFiPoweredOn == false ? localized("Wi-Fi disabled") : localized("Not connected")
        }
        switch network.transport {
        case .wifi: return network.ssid ?? localized("Network name unavailable")
        case .ethernet: return network.interfaceName ?? localized("Wired connection")
        case .other: return network.interfaceName ?? localized("Active connection")
        case .none: return localized("Not connected")
        }
    }

    private var networkSpeedText: String? {
        guard statusStore.status.network.isConnected,
              let speed = statusStore.networkSpeed else { return nil }
        let down = NetworkSpeedFormatter.compact(speed.downloadBytesPerSecond)
        let up = NetworkSpeedFormatter.compact(speed.uploadBytesPerSecond)
        return "↓\(down) ↑\(up)"
    }

    private var networkState: String {
        let network = statusStore.status.network
        guard network.isAvailable else { return localized("Unavailable") }
        if network.isWiFiPoweredOn == false, !network.isConnected { return localized("Off") }
        guard network.isConnected else { return localized("Offline") }
        switch network.transport {
        case .wifi: return localized("Wi-Fi")
        case .ethernet: return localized("Ethernet")
        case .other: return localized("Connected")
        case .none: return localized("Offline")
        }
    }

    private var wifiPowerToggle: AnyView? {
        guard let wifiPowerState = statusStore.status.network.isWiFiPoweredOn else { return nil }
        return AnyView(
            Toggle(localized("Wi-Fi power"), isOn: Binding(
                get: { wifiPowerState },
                set: { statusStore.setWiFiPower($0) }
            ))
            .labelsHidden()
            .toggleStyle(.switch)
            .controlSize(.mini)
            .accessibilityLabel(localized("Wi-Fi power"))
        )
    }

    private var audioOutputSymbol: String {
        guard let output = statusStore.status.audio.defaultOutput else { return "speaker.slash" }
        switch output.category {
        case .airPods: return "airpodspro"
        case .headphones, .bluetoothAudio: return "headphones"
        case .displayAudio: return "display"
        case .usbAudio, .builtInSpeaker, .other: return "speaker.wave.2"
        }
    }

    private var audioOutputDetail: String {
        statusStore.status.audio.defaultOutput?.name ?? localized("No output device")
    }

    private var audioInputSymbol: String {
        statusStore.status.audio.defaultInput == nil ? "mic.slash" : "mic"
    }

    private var audioInputDetail: String {
        statusStore.status.audio.defaultInput?.name ?? localized("No input device")
    }

    private var audioInputState: String {
        guard let input = statusStore.status.audio.defaultInput else { return localized("Unavailable") }
        switch input.transport {
        case .builtIn: return localized("Built-in")
        case .bluetooth, .bluetoothLE: return localized("Bluetooth")
        case .usb: return localized("USB")
        case .hdmi, .displayPort: return localized("Display")
        case .airPlay: return localized("AirPlay")
        case .virtual: return localized("Virtual")
        case .other: return localized("Connected")
        }
    }

    private var audioOutputState: String {
        guard let output = statusStore.status.audio.defaultOutput else { return localized("Unavailable") }
        if output.transport.isBluetooth {
            return output.temporaryGlyph == .airPods ? localized("AirPods") : localized("Bluetooth")
        }
        switch output.transport {
        case .builtIn: return localized("Built-in")
        case .airPlay: return localized("AirPlay")
        case .usb: return localized("USB")
        case .hdmi, .displayPort: return localized("Display")
        case .virtual: return localized("Virtual")
        case .bluetooth, .bluetoothLE: return localized("Bluetooth")
        case .other: return localized("Connected")
        }
    }
}

struct BatteryStatusRow: View {
    let battery: BatteryStatus
    let showPercentage: Bool
    var showsDisclosure = false
    var timeEstimate: BatteryTimeEstimate = .unavailable

    var body: some View {
        HStack(spacing: 11) {
            Image(systemName: symbol)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(.primary)
                .frame(width: 28, height: 28)
                .background(.primary.opacity(0.12), in: Circle())

            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 8) {
                    Text(localized("Battery"))
                        .font(.system(size: 12.5, weight: .semibold))
                    Spacer(minLength: 8)
                    if let trailingValue {
                        Text(trailingValue)
                            .font(.system(size: 10.5, weight: .medium, design: .rounded))
                            .foregroundStyle(.secondary)
                            .monospacedDigit()
                    }
                }
                HStack(spacing: 6) {
                    Text(detail)
                        .font(.system(size: 10.5))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.72)
                    if let secondaryDetail {
                        Spacer(minLength: 0)
                        Text(secondaryDetail)
                            .font(.system(size: 10.5, weight: .medium, design: .rounded))
                            .foregroundStyle(.secondary)
                            .monospacedDigit()
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)
                    }
                }
            }

            if showsDisclosure {
                Image(systemName: "chevron.right")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(.horizontal, 10)
        .frame(height: 48)
        .popoverCardBackground(cornerRadius: 11, fillOpacity: 0.045)
    }

    var trailingValue: String? {
        guard showPercentage, let percentage = battery.percentage else { return nil }
        return localized("%d%%", percentage)
    }

    var detail: String {
        guard battery.isAvailable else { return localized("No internal battery") }
        if battery.isFullyCharged { return localized("Fully charged") }
        if battery.isCharging { return localized("Charging") }
        if battery.isPluggedIn { return localized("Charging On Hold") }
        if battery.isLowPowerModeEnabled { return localized("Low Power Mode") }
        return localized("Using battery power")
    }

    var secondaryDetail: String? {
        guard battery.isAvailable else { return nil }
        switch timeEstimate {
        case .toFull(let minutes):
            return localized("%@ to full", BatteryTimeFormatter.duration(minutes: minutes))
        case .toEmpty(let minutes):
            return localized("%@ left", BatteryTimeFormatter.duration(minutes: minutes))
        case .calculating:
            return localized("Calculating…")
        case .unavailable:
            break
        }
        return battery.isPluggedIn ? localized("Using Adapter") : nil
    }

    var symbol: String {
        if battery.isFullyCharged { return "battery.100percent" }
        if battery.isCharging { return "battery.100percent.bolt" }
        switch battery.percentage ?? 0 {
        case 76...100: return "battery.100percent"
        case 51...75: return "battery.75percent"
        case 26...50: return "battery.50percent"
        default: return "battery.25percent"
        }
    }
}

#if DEBUG
private struct DebugStatusSimulatorView: View {
    let statusStore: SystemStatusStore
    @AppStorage(PreferenceKeys.batteryColorCoding) private var batteryColorCoding = false
    @ObservedObject private var adaptiveRingMonitor = AdaptiveRingMonitor.shared

    var body: some View {
        Menu {
            Menu("Simulate") {
                simulationControls
            }

            Menu("Diagnostics") {
                diagnosticItem("Laptop Ring Mode", value: laptopRingModeLabel)
                diagnosticItem("Charging session", value: chargingSessionLabel)
                diagnosticItem("Waiting for full charge", value: waitingForFullChargeLabel)
                diagnosticItem("Adaptive telemetry lease", value: adaptiveRingMonitor.monitoringOwnerCount > 0 ? "Active" : "Inactive")
                diagnosticItem("Adaptive monitor", value: adaptiveRingMonitor.isMonitoring ? "Running" : "Stopped")
                diagnosticItem("Adaptive source", value: adaptiveRingMonitor.debugTestSource.rawValue)
                diagnosticItem("Brightness", value: brightnessLabel)
                diagnosticItem("Adaptive metric", value: adaptiveRingMonitor.state.diagnosticLabel)
                diagnosticItem("Adaptive progress", value: adaptiveProgressLabel)
                diagnosticItem("Final ring target", value: finalRingOverrideLabel)
            }
        } label: {
            HStack {
                Label("Debug Simulator", systemImage: "hammer")
                    .font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(.secondary)
                Spacer()
                Text(debugSummary)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(.tertiary)
                Image(systemName: "chevron.right")
                    .font(.system(size: 8.5, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
            .contentShape(Rectangle())
        }
        .menuStyle(.borderlessButton)
        .buttonStyle(.plain)
        .padding(.horizontal, 6)
        .frame(minHeight: 26)
    }

    @ViewBuilder
    private var simulationControls: some View {
        Menu("Battery Level") {
            ForEach(DebugBatteryLevel.allCases) { level in
                Button(level.title) { statusStore.applyDebugBatteryLevel(level) }
            }
        }
        Menu("Battery Power") {
            ForEach(DebugPowerState.allCases) { powerState in
                Button(powerState.rawValue) { statusStore.applyDebugPowerState(powerState) }
            }
        }
        Menu("Low Power Mode") {
            ForEach(DebugLowPowerMode.allCases) { lowPowerMode in
                Button(lowPowerMode.rawValue) { statusStore.applyDebugLowPowerMode(lowPowerMode) }
            }
        }
        Menu("Battery Color Coding") {
            Button("Off") { batteryColorCoding = false }
            Button("On") { batteryColorCoding = true }
        }
        Menu("MacBook Adaptive Ring") {
            Button("Battery / Unplugged") {
                statusStore.applyDebugAdaptiveBatteryBaseline()
                adaptiveRingMonitor.clearDebugSyntheticInput()
            }
            Button("Charging") {
                scheduleAdaptiveChargingSimulation()
            }
            Divider()
            Button("Adaptive — Neutral") { scheduleAdaptive(.neutral) }
            Button("Adaptive — Brightness") { scheduleAdaptive(.brightness50) }
            Button("Adaptive — CPU") { scheduleAdaptive(.cpuHigh) }
            Button("Adaptive — Memory") { scheduleAdaptive(.memoryPressure) }
            Button("Adaptive — Thermal") { scheduleAdaptive(.thermalSerious) }
            Divider()
            Button("Use Live System State") {
                adaptiveRingMonitor.clearDebugSyntheticInput()
                statusStore.restoreLiveStatus()
            }
        }
        Menu("Network") {
            ForEach(DebugNetworkState.allCases) { networkState in
                Button(networkState.rawValue) { statusStore.applyDebugNetworkState(networkState) }
            }
        }
        Menu("Volume") {
            ForEach(DebugVolumeState.allCases) { volumeState in
                Button(volumeState.rawValue) { statusStore.applyDebugVolumeState(volumeState) }
            }
        }
        Menu("Audio Connection") {
            ForEach(DebugAudioDeviceState.allCases) { deviceState in
                Button(deviceState.rawValue) { statusStore.applyDebugAudioDeviceState(deviceState) }
            }
        }
        Divider()
        Button("Restore Live Data") { statusStore.restoreLiveStatus() }
    }

    private func diagnosticItem(_ title: String, value: String) -> some View {
        Button("\(title): \(value)") {}
            .disabled(true)
    }

    private var debugSummary: String {
        "\(laptopRingModeLabel) · \(adaptiveRingMonitor.debugTestSource.rawValue)"
    }

    private var laptopRingModeLabel: String {
        switch statusStore.laptopRingModeState.mode {
        case .battery: "Battery"
        case .adaptive: "Adaptive"
        }
    }

    private var chargingSessionLabel: String {
        guard let start = statusStore.laptopRingModeState.sessionStartPercentage,
              let target = statusStore.laptopRingModeState.targetPercentage
        else { return "None" }
        let waiting = statusStore.laptopRingModeState.isWaitingForFullChargeDelay ? " · waiting for full delay" : ""
        return "\(start)% → \(target)%\(waiting)"
    }

    private var waitingForFullChargeLabel: String {
        statusStore.laptopRingModeState.isWaitingForFullChargeDelay ? "Yes" : "No"
    }

    private var brightnessLabel: String {
        guard let availability = adaptiveRingMonitor.brightnessSnapshot?.availability else { return "Sampling…" }
        switch availability {
        case .available(let value): return String(format: "%.0f%%", value * 100)
        case .unavailable: return "Unavailable"
        }
    }

    private var adaptiveProgressLabel: String {
        let target = AdaptiveRingVisualTarget(state: adaptiveRingMonitor.state).progress
        return String(format: "%.1f%%", target * 100)
    }

    private var finalRingOverrideLabel: String {
        guard statusStore.usesAdaptiveRing else { return "Battery Ring" }
        let target = AdaptiveRingVisualTarget(state: adaptiveRingMonitor.state).progress
        return String(format: "%.1f%%", target * 100)
    }

    private func scheduleAdaptiveChargingSimulation() {
        Task { @MainActor in
            statusStore.applyDebugAdaptiveChargingBaseline()
            adaptiveRingMonitor.clearDebugSyntheticInput()
            adaptiveQALog("DEBUG controller prepared at 50%; visible Charging percentage preserved; awaiting 80% target")
        }
    }

    private func scheduleAdaptive(_ scenario: AdaptiveRingSyntheticScenario) {
        Task { @MainActor in
            await activateAdaptive(scenario)
        }
    }

    @MainActor
    private func activateAdaptive(_ scenario: AdaptiveRingSyntheticScenario) async {
        if statusStore.laptopRingModeState.mode == .adaptive {
            useAdaptiveSourceScenario(scenario)
            return
        }

        // Direct selection first lets the real Charging presentation settle.
        if statusStore.laptopRingModeState.targetPercentage != DebugBatteryLevel.eighty.rawValue
            || !statusStore.status.battery.isCharging {
            statusStore.applyDebugAdaptiveChargingBaseline()
            try? await Task.sleep(for: .seconds(BatteryChargingAnimationProfile.entranceDuration))
            guard !Task.isCancelled else { return }
        }

        useAdaptiveSourceScenario(scenario)
        await Task.yield()
        statusStore.reachDebugAdaptiveTarget()
        adaptiveQALog("DEBUG crossed controller target without publishing a synthetic battery jump for \(scenario.rawValue)")
    }

    private func useAdaptiveSourceScenario(_ scenario: AdaptiveRingSyntheticScenario) {
        let preference: PerformancePreference = scenario == .memoryPressure ? .memory : .automatic
        adaptiveRingMonitor.useDebugSyntheticInput(
            scenario.input,
            label: scenario.rawValue,
            preference: preference
        )
    }

    private func adaptiveQALog(_ message: String) {
        NSLog("%@", "[DuoBar Adaptive QA] \(message)")
    }
}
#endif
