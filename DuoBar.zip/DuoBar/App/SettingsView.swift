import ServiceManagement
import SwiftUI

struct SettingsView: View {
    @AppStorage(PreferenceKeys.showBatteryPercentage) private var showBatteryPercentage = true
    @AppStorage(PreferenceKeys.animationsEnabled) private var animationsEnabled = true
    @AppStorage(PreferenceKeys.menuBarIconScale) private var menuBarIconScale = MenuBarIconSize.defaultScale
    @AppStorage(PreferenceKeys.batteryColorCoding) private var batteryColorCoding = false
    @AppStorage(PreferenceKeys.adaptiveRingPriority) private var adaptiveRingPriorityRaw = PerformancePreference.automatic.rawValue
    @AppStorage(PreferenceKeys.adaptiveRingColorCoding) private var adaptiveRingColorCoding = false
    @AppStorage(PreferenceKeys.openOnHover) private var openOnHover = false
    @AppStorage(PreferenceKeys.showInDock) private var showInDock = false
    @AppStorage(PreferenceKeys.showDesktopWidget) private var showDesktopWidget = false
    @AppStorage(PreferenceKeys.desktopWidgetCustomDots) private var desktopWidgetCustomDots = DesktopWidgetDotsSource.volume.rawValue
    @AppStorage(PreferenceKeys.desktopWidgetCustomCenter) private var desktopWidgetCustomCenter = DesktopWidgetCenterSource.network.rawValue
    @AppStorage(PreferenceKeys.desktopWidgetCustomRing) private var desktopWidgetCustomRing = DesktopWidgetRingSource.battery.rawValue
    @AppStorage(PreferenceKeys.desktopWidgetSize) private var desktopWidgetSize = DesktopWidgetSize.medium.rawValue
    @AppStorage(PreferenceKeys.showBatteryPercentageInMenuBar) private var showBatteryPercentageInMenuBar = false
    @AppStorage(PreferenceKeys.appLanguage) private var appLanguage = ""
    @StateObject private var launchAtLogin = LaunchAtLoginService()
    @ObservedObject private var adaptiveRingMonitor = AdaptiveRingMonitor.shared
    private let deviceContextService = DeviceContextService()
    #if DEBUG
    @AppStorage(PreferenceKeys.simulateDesktopMac) private var simulateDesktopMac = false
    #endif

    var body: some View {
        Form {
            Section(localized("Menu Bar")) {
                Toggle(localized("Show battery percentage in popover"), isOn: $showBatteryPercentage)
                Toggle(localized("Battery Percentage"), isOn: $showBatteryPercentageInMenuBar)
                Toggle(localized("Enable animations"), isOn: $animationsEnabled)

                VStack(alignment: .leading, spacing: 6) {
                    Text(localized("Icon Size"))
                    Picker(localized("Icon Size"), selection: resolvedMenuBarIconScale) {
                        Text(localized("Small")).tag(MenuBarIconSize.minimumScale)
                        Text(localized("Default")).tag(MenuBarIconSize.defaultScale)
                        Text(localized("Large")).tag(MenuBarIconSize.largeScale)
                        Text(localized("Extra Large")).tag(MenuBarIconSize.extraLargeScale)
                    }
                    .pickerStyle(.segmented)
                    .accessibilityLabel(localized("Menu bar icon size"))
                    HStack(spacing: 10) {
                        Text(localized("Small"))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Slider(
                            value: resolvedMenuBarIconScale,
                            in: MenuBarIconSize.minimumScale...MenuBarIconSize.maximumScale,
                            step: MenuBarIconSize.step
                        )
                        .accessibilityLabel(localized("Menu bar icon size"))
                        .accessibilityValue(localized("%d%%", Int((MenuBarIconSize.resolve(menuBarIconScale) * 100).rounded())))
                        Text(localized("Large"))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Text(localized("Choose a preset or fine-tune DuoBar to better match your menu bar."))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Section(localized("General")) {
                VStack(alignment: .leading, spacing: 4) {
                    Toggle(localized("Open on Hover"), isOn: $openOnHover)
                        .toggleStyle(.switch)
                    Text(localized("Open DuoBar when the pointer moves over the menu bar icon."))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Toggle(localized("Show in Dock"), isOn: $showInDock)
                        .toggleStyle(.switch)
                    Text(localized("Show the DuoBar icon in the Dock. Clicking it opens Settings."))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Toggle(localized("Desktop Widget"), isOn: $showDesktopWidget)
                        .toggleStyle(.switch)
                    Text(localized("Show DuoBar on the desktop. Click the widget to switch modes; drag it to move it."))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                if showDesktopWidget {
                    Picker(localized("Custom Mode Dots"), selection: $desktopWidgetCustomDots) {
                        ForEach(DesktopWidgetDotsSource.allCases, id: \.self) { source in
                            Text(source.title).tag(source.rawValue)
                        }
                    }

                    Picker(localized("Custom Mode Center"), selection: $desktopWidgetCustomCenter) {
                        ForEach(DesktopWidgetCenterSource.allCases, id: \.self) { source in
                            Text(source.title).tag(source.rawValue)
                        }
                    }

                    Picker(localized("Custom Mode Ring"), selection: $desktopWidgetCustomRing) {
                        ForEach(DesktopWidgetRingSource.allCases, id: \.self) { source in
                            Text(source.title).tag(source.rawValue)
                        }
                    }

                    Picker(localized("Widget Size"), selection: $desktopWidgetSize) {
                        ForEach(DesktopWidgetSize.allCases, id: \.self) { size in
                            Text(size.title).tag(size.rawValue)
                        }
                    }
                }

                Toggle(
                    localized("Launch DuoBar at login"),
                    isOn: Binding(
                        get: { launchAtLogin.isEnabled },
                        set: launchAtLogin.setEnabled
                    )
                )

                if launchAtLogin.requiresApproval {
                    Text(localized("Approval is required in System Settings → General → Login Items."))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                if let errorMessage = launchAtLogin.errorMessage {
                    Text(errorMessage)
                        .font(.caption)
                        .foregroundStyle(.red)
                        .textSelection(.enabled)
                }

                Picker(localized("Language"), selection: $appLanguage) {
                    ForEach(AppLanguage.allCases, id: \.self) { language in
                        Text(language.displayName).tag(language.rawValue)
                    }
                }
            }

            if showsBatteryRingSettings {
                Section(localized("Battery Ring")) {
                    Toggle(localized("Battery Color Coding"), isOn: $batteryColorCoding)
                }
            }

            if showsAdaptiveRingSettings {
                Section(localized("Adaptive Ring")) {
                    Picker(localized("Adaptive Ring Priority"), selection: adaptiveRingPriority) {
                        ForEach(PerformancePreference.allCases, id: \.self) { preference in
                            Text(preference.localizedDisplayName).tag(preference)
                        }
                    }
                    Text(localized("Used only when multiple system conditions need attention. Critical conditions can still take priority."))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Toggle(localized("Adaptive Ring Color Coding"), isOn: $adaptiveRingColorCoding)
                }
            }

            #if DEBUG
            if !MarketingCaptureMode.isEnabled {
                DebugPerformanceDiagnosticsView()
                DebugDuoGlyphTuningView()
            }
            #endif
        }
        .formStyle(.grouped)
        .scenePadding()
        .frame(minWidth: 420, idealWidth: 420, maxWidth: .infinity, minHeight: 340, idealHeight: settingsHeight, maxHeight: .infinity)
        .background(SettingsWindowConfigurator())
        .navigationTitle(localized("DuoBar Settings"))
        .onAppear {
            NSApp.activate(ignoringOtherApps: true)
            launchAtLogin.refresh()
            if showsAdaptiveRingSettings {
                adaptiveRingMonitor.setPreference(adaptiveRingPriority.wrappedValue)
            }
        }
        .onChange(of: adaptiveRingPriorityRaw) { _ in
            if showsAdaptiveRingSettings {
                adaptiveRingMonitor.setPreference(adaptiveRingPriority.wrappedValue)
            }
        }
    }

    private var settingsHeight: CGFloat {
        #if DEBUG
        MarketingCaptureMode.isEnabled ? 360 : 850
        #else
        360
        #endif
    }

    private var adaptiveRingPriority: Binding<PerformancePreference> {
        Binding(
            get: { PerformancePreference(rawValue: adaptiveRingPriorityRaw) ?? .automatic },
            set: { adaptiveRingPriorityRaw = $0.rawValue }
        )
    }

    private var resolvedMenuBarIconScale: Binding<Double> {
        Binding(
            get: { MenuBarIconSize.resolve(menuBarIconScale) },
            set: { menuBarIconScale = MenuBarIconSize.resolve($0) }
        )
    }

    private var showsAdaptiveRingSettings: Bool {
        #if DEBUG
        AdaptiveRingSettingsEligibility.isEligible(
            for: deviceContextService.current(),
            simulateDesktop: simulateDesktopMac
        )
        #else
        AdaptiveRingSettingsEligibility.isEligible(for: deviceContextService.current())
        #endif
    }

    private var showsBatteryRingSettings: Bool {
        #if DEBUG
        deviceContextService.current(simulateDesktop: simulateDesktopMac).ringBehavior == .batteryRing
        #else
        deviceContextService.current().ringBehavior == .batteryRing
        #endif
    }
}
